#Nama : Aji sakti saputra
#NRP : 2C2230012
#TANGGAL :10-14-2024
#DESKRIPSI : menjelaskan bagaimana Tuan Ro menentukan barang mana yang harus ditawarkan kepada pembeli. 


# Fungsi untuk menghitung keuntungan

def hitung_keuntungan(harga_dasar, harga_jual):
    return harga_jual - harga_dasar

# Input harga dasar dan harga jual untuk masing-masing barang
harga_dasar_A = float(input("Masukkan harga dasar barang A: "))
harga_jual_A = float(input("Masukkan harga jual barang A: "))

harga_dasar_B = float(input("Masukkan harga dasar barang B: "))
harga_jual_B = float(input("Masukkan harga jual barang B: "))

harga_dasar_C = float(input("Masukkan harga dasar barang C: "))
harga_jual_C = float(input("Masukkan harga jual barang C: "))

# Menghitung keuntungan untuk setiap barang
keuntungan_A = hitung_keuntungan(harga_dasar_A, harga_jual_A)
keuntungan_B = hitung_keuntungan(harga_dasar_B, harga_jual_B)
keuntungan_C = hitung_keuntungan(harga_dasar_C, harga_jual_C)

# Menentukan barang dengan keuntungan terbesar
if keuntungan_A > keuntungan_B and keuntungan_A > keuntungan_C:# HARUS A YANG PALING TINGGI DI BANDING DENGAN B DAN C JIKA TIDAK MAKA HASIL FALSE
    barang_terbaik = "A"#JIKA HASIL TRUE
elif keuntungan_B > keuntungan_A and keuntungan_B > keuntungan_C:#HARUS B YANG PALING TINGGI DI BANDING A DAN C JIKA TIDAK MAKA HASIL FALSE
    barang_terbaik = "B"#JIKA HASIL TRUE
else:
    barang_terbaik = "C" #JIKA A DAN B LEBIH KECIL DARI C, MAKA C PALING TINGGI DIIBANDING A DAN B

# Menampilkan hasil
print(f"Barang yang harus ditawarkan adalah barang {barang_terbaik}")