#Nama : Aji sakti saputra
#NRP : 2C2230012
#TANGGAL :10-14-2024
#DESKRIPSI : MENENTUKAN PEMBAGIAN KELAS MAHASISWA


# Kelas berdasarkan akhiran NRP
def tentukan_kelas(nrp_akhir):
    # Mengonversi input menjadi integer
    nrp_akhir = int(nrp_akhir)

    # Menentukan kelas berdasarkan rentang NRP
    if 1 <= nrp_akhir <= 100: #UNTUK NRP 1 SAMPAI DENGAN 100
        if nrp_akhir % 2 == 0: # NRP_AKHIR DI MODULUS 2 DAN HASILNYA NOL MAKA HASILNYA GENAP
            return "K2"#JIKA TRUE MAKA GENAP
        else:
            return "K1" #JIKA FALSE MAKA GANJIL
    elif 101 <= nrp_akhir <= 200:#UNTUK NRP_AKHIR 101 SAMPAI DENGAN 200
        if nrp_akhir % 2 == 0:#NRP_AKHIR DI MODULUS 2 DAN HASILNYA NOL MAKA HASILNYA GENAP
            return "K4"#JIKA TRUE MAKA GENAP
        else:
            return "K3"#JIKA FALSE MAKA GANJIL
    elif 201 <= nrp_akhir <= 300:#UNTUK NRP 201 SAMPAI DENGAN 300
        if nrp_akhir % 2 == 0:#NRP_AKHIR DI MODULUS 2 DAN HASILNYA NOL MAKA HASILNYA  GENAP
            return "K6"#JIKA TRUE MAKA GENAP
        else:
            return "K5"#JIKA FALSE MAKA GANJIL
    elif nrp_akhir > 300:#NRP_AKHIR LEBIH DARI 300
        if nrp_akhir % 2 == 0:#NRP_AKHIR DI MODULUS 2 DAN HASILNYA NOL MAKA HASILNYA GENAP
            return "K8"#JIKA TRUE MAKA GENAP
        else:
            return "K7"#JIKA FALSE MAKA GANJIL
    else:
        return "NRP tidak valid"#<-OUTPUT TERSEBUT AKAN KELUAR JIKA TIDAK SESUAI KRITERIA STATEMENT DIATAS

# Input akhiran NRP dari pengguna
nrp_akhir = input("Masukan akhiran NRP: ")
kelas = tentukan_kelas(nrp_akhir)#PEMANGGILAN OUTPUT

# Menampilkan hasil
print(f"Mahasiswa masuk ke kelas {kelas}")